from django.contrib import admin

from fypapp.models import Contact

from fypapp.models import Blog

# Register your models here.

admin.site.register(Contact)
 
admin.site.register(Blog)
