from django.urls import URLPattern, path
from xml.dom.minidom import Document
from django.urls import include, path

from . import views

 
urlpatterns = [
    path('', views.index, name='index'),
    path('signup', views.signup, name='signup'),
    path('contact', views.Contact_Us, name='contact'),
    path('blog', views.blog, name='blog'),
]

# urlpatterns = [
#     path('', views.index, name='index'), #our-domain.com
#     path('contact-us/', views.Contact_Us, name='ContactUs'),
#     path('signup/', views.Signup, name='Signup') ,
#     path('login/', views.Login, name='Login') ,
#     path('logout/', views.Logout, name='Logout') ,
#     path('blogs/', views.blogHome, name='BlogsPage'),
#     path('blogs/<slug:slug>', views.singleBlog, name='singleBlog'),
 
# ]
