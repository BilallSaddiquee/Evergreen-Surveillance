from django.shortcuts import render, HttpResponse, redirect
from email import message
from django.contrib import messages #import messages
from pyexpat.errors import messages
from traceback import print_tb
from urllib import request
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
# from myapp.models import Blog
from fypapp import models


# Create your views here.
def index(request):
    return render(request, 'fypapp/includes/index.html')

def signup(request):
    return render(request, 'fypapp/includes/signup.html')

def Contact_Us(request):
        if request.method=='POST':
            name = request.POST['name']
            email = request.POST['email']
            number = request.POST.get('number')
            desc = request.POST.get('desc')
            # print(name, email, number, desc)
            ins = models.Contact(name=name, email=email, phone=number, desc=desc)
            ins.save()
            print('The data has been written to the db.')
        return render(request, 'fypapp/includes/contact.html')

def blog(request):
    return render(request, 'fypapp/includes/blog.html')


# def Contact_Us(request):
#     if request.method=='POST':
#         name = request.POST['name']
#         email = request.POST['email']
#         number = request.POST.get('number')
#         desc = request.POST.get('desc')
#         # print(name, email, number, desc)
#         ins = models.Contact(name=name, email=email, phone=number, desc=desc)
#         ins.save()
#         print('The data has been written to the db.')
 
#     #return HttpResponse ("This is my contact page(/contact-us)"
#     return render(request, 'fypapp/includes/contact.html')
